import java.time.Duration;
import java.time.LocalDateTime;

public class Cancion {
    private final String titulo;
    private final String artista;
    private final  String album;
    private final int anioAlbum;
    private int reproducciones;
    private int likes;
    private int dislikes;
    private LocalDateTime ultimaReproduccion;

    public Cancion(String titulo, String artista, String album, int anioAlbum) {
        this.titulo = titulo;
        this.artista = artista;
        this.album = album;
        this.anioAlbum = anioAlbum;
        this.reproducciones = 0;
        this.likes = 0;
        this.dislikes = 0;
        this.ultimaReproduccion = null;
    }

    public void reproducir() {
        this.reproducciones++;
        this.ultimaReproduccion = LocalDateTime.now();
    }

    public void darLike() {
        this.likes++;
    }

    public void darDislike() {
        this.dislikes++;
        if (this.dislikes >= 5000) {
            // Volver a la popularidad normal si tiene más de 5000 dislikes.
            this.reiniciarPopuularidad();
        }
    }

    public String obtenerDetallePopularity() {
        if (this.reproducciones <= 1000) {
            return obtenerDetalleNormal();
        } else if (this.reproducciones <= 50000 && this.likes >= 20000) {
            return obtenerDetalleEnAuge();
        } else if (this.ultimaReproduccion != null && Duration.between(ultimaReproduccion, LocalDateTime.now()).toHours() <= 24) {
            return obtenerDetalleEnTendencia();
        } else {
            // Volver a la popularidad normal si no ha sido reproducida en las últimas 24 horas.
            this.reiniciarPopuularidad();
            return obtenerDetalleNormal();
        }
    }

    private void reiniciarPopuularidad() {
        this.reproducciones = 0;
        this.likes = 0;
        this.dislikes = 0;
        this.ultimaReproduccion = null;
    }

    private String obtenerDetalleNormal() {
        return Icono.MUSICAL_NOTE.texto() + " - " + artista + " - " + album + " - " + titulo;
    }

    private String obtenerDetalleEnAuge() {
        return Icono.ROCKET.texto() + " - " + artista + " - " + titulo + " (" + album + " - " + anioAlbum + ")";
    }

    private String obtenerDetalleEnTendencia() {
        return Icono.FIRE.texto() + " - " + titulo + " - " + artista + " (" + album + " - " + anioAlbum + ")";
    }

    public static void main(String[] args) {
        // pruebas
        Cancion theScientist = new Cancion("The Scientist", "Coldplay", "A Rush of Blood to the head", 2002);

        System.out.println("Caso de prueba 1:");
        System.out.println(theScientist.obtenerDetallePopularity());

        theScientist.reproducir();
        System.out.println("\nCaso de prueba 2:");
        System.out.println(theScientist.obtenerDetallePopularity());

        theScientist.darDislike();
        System.out.println("\nCaso de prueba 3:");
        System.out.println(theScientist.obtenerDetallePopularity());

        for (int i = 0; i < 50001; i++) {
            theScientist.reproducir();
            theScientist.darLike();
        }
        System.out.println("\nCaso de prueba 4:");
        System.out.println(theScientist.obtenerDetallePopularity());

        theScientist.ultimaReproduccion = LocalDateTime.now().minusHours(25);
        System.out.println("\nCaso de prueba 5:");
        System.out.println(theScientist.obtenerDetallePopularity());
    }

    public void setUltimaReproduccion(LocalDateTime localDateTime) {
    }
}
