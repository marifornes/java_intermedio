import java.time.LocalDateTime;

public class Main {
    public static void main(String[] args) {
        // pruebas
        Cancion theScientist = new Cancion("The Scientist", "Coldplay", "A Rush of Blood to the head", 2002);

        System.out.println("Caso de prueba 1:");
        System.out.println(theScientist.obtenerDetallePopularity());

        theScientist.reproducir();
        System.out.println("\nCaso de prueba 2:");
        System.out.println(theScientist.obtenerDetallePopularity());

        theScientist.darDislike();
        System.out.println("\nCaso de prueba 3:");
        System.out.println(theScientist.obtenerDetallePopularity());

        for (int i = 0; i < 50001; i++) {
            theScientist.reproducir();
            theScientist.darLike();
        }
        System.out.println("\nCaso de prueba 4:");
        System.out.println(theScientist.obtenerDetallePopularity());

        theScientist.setUltimaReproduccion(LocalDateTime.now().minusHours(25));
        System.out.println("\nCaso de prueba 5:");
        System.out.println(theScientist.obtenerDetallePopularity());
    }
}
